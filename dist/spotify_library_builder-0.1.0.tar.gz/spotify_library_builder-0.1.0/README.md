# SpotifyLibraryBuilder

A command-line tool that turns any public Spotify playlist into a neatly-organised local MP3 collection. Tracks are located on YouTube, downloaded with **yt-dlp**, and converted to MP3 using **ffmpeg**.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .  # development install
```

Dependencies:

- Python 3.9+
- ffmpeg (must be on your `$PATH`) – macOS: `brew install ffmpeg`, Ubuntu: `sudo apt install ffmpeg`, Windows: see <https://ffmpeg.org/download.html>.

This installs the console script `sp-lib-builder`.

## Configuration

1. Copy `env.template` → `.env`
2. Fill in your API credentials:
   - **Spotify** `SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`
   - **Google / YouTube Data API v3** `YOUTUBE_API_KEY`

The `.env` file is loaded automatically at runtime.

## Usage

```bash
# Basic – save into ~/Downloads
sp-lib-builder <spotify-playlist-id>

# Choose a different root directory
sp-lib-builder <playlist-id> --output /path/to/library
```

For every run the tool creates a timestamped folder inside the `--output` directory, e.g.:

```
/path/to/library/
└── sp-lib-builder-07-03-2025-15-42-10/
    ├── Track-1.mp3
    ├── Track-2.mp3
    └── ...
```

### What happens under the hood?

1. Playlist metadata is fetched from Spotify.
2. The first matching YouTube video for each song is located via the YouTube Data API.
3. yt-dlp downloads the best audio stream and converts it to MP3 (192 kbps) via ffmpeg.
4. Files are written to the timestamped folder, avoiding name collisions automatically.

Progress is shown with a live `tqdm` progress-bar and detailed log output.

## Project layout

```
src/spotify_library_builder/
    cli.py            # Command-line interface
    config.py         # Environment variable handling
    converter.py      # yt-dlp + ffmpeg integration
    spotify_client.py # Spotify API wrapper
    youtube_client.py # YouTube search wrapper
    utils.py          # Generic utilities
```

## Publishing to PyPI

1. Ensure `pyproject.toml` has an up-to-date version and author/contact info.
2. Update the changelog (if any) and commit your changes.
3. Build the distribution artifacts:
   ```bash
   python -m build   # requires `pip install build`
   ```
4. Upload to PyPI (test first!):
   ```bash
   python -m twine upload --repository testpypi dist/*
   # once happy:
   python -m twine upload dist/*
   ```

## Disclaimer

This project interacts with Spotify and YouTube. Make sure your usage complies with their respective terms of service.
