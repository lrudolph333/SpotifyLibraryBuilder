from __future__ import annotations

"""Allows ``python -m spotify_library_builder <playlist_id>`` to work."""

from .cli import main

if __name__ == "__main__":
    main() 